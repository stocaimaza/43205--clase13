import Productos from './componentes/Productos/Productos';
import './App.css';

function App() {
  return (
    <>
      <Productos/>
     
    </>
  );
}

export default App;

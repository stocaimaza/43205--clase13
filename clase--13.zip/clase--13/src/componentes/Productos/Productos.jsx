import { useState, useEffect } from "react";
//Importamos los hooks que vamos a utilizar

//Importamos las funciones de Firebase que vamos a utilizar: 
import { collection, query, getDocs, where, doc, updateDoc } from "firebase/firestore";
//Recuerden que en Firestore las colecciones tienen documentos en su interior. 
//collection me permite obtener una colección. 
//query la uso cuando quiero generar una consulta a la base de datos.
//getDocs me permite obtener los documentos de una colección. 
//where la uso para agregar filtros a mis consultas. 

import { db } from "../../services/config";
//Importamos db que tiene mi configuración para conectarme a la base de datos. 

import './Productos.css'
const Productos = () => {
    const [productos, setProductos] = useState([]);

    useEffect(() => {

        //Si quisiera aplicar un filtro puedo usar where: 
        const misProductos = query(collection(db, "productos"), where("precio", "<", 500));

        //const misProductos = query(collection(db, "productos"));

        getDocs(misProductos)
            .then(respuesta => {
                setProductos(respuesta.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
                //Creo un nuevo array que contenga los datos del producto y además el ID. 
            })
    }, [productos])

    //Modificación: quiero descontar stock cada vez que hago click en "comprar". 

    const descontarStock = async (producto) => {
        const productoRef = doc(db, "productos", producto.id);
        let nuevoStock = producto.stock - 1;

        await updateDoc(productoRef, {stock: nuevoStock});

    }

    return (
        <>
            <h2>Mis Productos</h2>
            <div className="productos-container">
                {
                    productos.map((producto) => (
                        <div className="producto-card" key={producto.id}>
                            <h2> {producto.nombre} </h2>
                            <p>Precio: ${producto.precio} </p>
                            <p>Stock: {producto.stock} </p>
                            <button onClick={()=> descontarStock(producto)}> Comprar </button>
                        </div>
                    ))
                }
            </div>

        </>
    )
}

export default Productos
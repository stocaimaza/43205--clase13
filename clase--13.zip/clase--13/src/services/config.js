import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore";
//Vamos a importar dos funciones de la librería Firebase. 
//initializeApp =  esta función la utilizo para INICIAR LA CONEXIÓN CON FIREBASE. 
//getFirestore = se utiliza para obtener una instancia de Firestore. 

//Creamos un objeto con toda nuestra información de la cuenta. 
// Acá se incluye la key personal de acceso a la BD. 

const firebaseConfig = {
  apiKey: "AIzaSyAKqlFcAWy5VaTyY8T2_8WVQ8p29V2n9c0",
  authDomain: "tienda-supermercado.firebaseapp.com",
  projectId: "tienda-supermercado",
  storageBucket: "tienda-supermercado.appspot.com",
  messagingSenderId: "723164346165",
  appId: "1:723164346165:web:59d5dd3618d73054f4be7c"
};


//Inicializamos Firebase y se pasa la configuración como argumento.  
//Esto devuelve una instancia de Firebase. 

const app = initializeApp(firebaseConfig);

//Uso esa instancia de Firebase para obtener una instancia de Firestore. 

export const db = getFirestore(app);
//Exportamos esta referencia para que este disponible en toda nuestra aplicación. 